package main;

class CourseException extends Exception{
    CourseException(String s){
        super(s);
    }
}
