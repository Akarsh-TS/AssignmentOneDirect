package main;

public class UniqueRollException extends Exception {
    UniqueRollException(String s){
        super(s);
    }
}
