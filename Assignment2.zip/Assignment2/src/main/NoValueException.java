package main;


   public class NoValueException extends Exception{
        NoValueException(String s){
            super(s);
        }
    }

